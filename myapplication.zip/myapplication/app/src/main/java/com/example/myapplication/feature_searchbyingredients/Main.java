package com.example.myapplication.feature_searchbyingredients;

public class Main {
    public static void main(String[] args)
    {
        //RecipeDatabase obj = new RecipeDatabase();
        //ArrayList<Recipe> show = obj.getDatabase();

        IngredientSearch x = new IngredientSearch("Cheese");
        x.showList();
    }}
